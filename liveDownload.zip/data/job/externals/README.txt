Local copy of libraries:
  1. https://cdn.jsdelivr.net/npm/mpd-parser@1.3.1/dist/mpd-parser.js
  2. https://cdnjs.cloudflare.com/ajax/libs/m3u8-parser/7.2.0/m3u8-parser.js
